/*
 * @Author: LXK9301 https://github.com/LXK9301
 * @Date: 2020-11-10 14:07:07 
 * @Last Modified by: LXK9301
 * @Last Modified time: 2020-11-23 12:27:16
 */
/*

娜塔莉波特曼哈佛毕业演讲：找到自己人生的理由
文章来源：未知 文章作者：enread 发布时间：2020-05-18 09:17 字体： [大 中 小]　 进入论坛
(单词翻译:双击或拖选)
　　Hello, class of 2015. I am so honorest to be here today. Dean Khurana, faculty1, parents, and most especially graduating students. Thank you so much for inviting2 me. The Senior Class Committee. it’s genuinely one of the most exciting things I've ever been asked to do.
 
　　I have to admit primarily because I can’t deny it as it was leaked in the WikiLeaks release of the Sony hack3 that hen I was invited I replied and I directly quotemy own email.” Wow! This is so nice!” ”I’m gonna need some funny ghost writers.Any ideas? ”This initial response now blessly public was from the knowledge that at my class day we were lucky enough to have Will Ferrel as class dayspeaker and many of us were hung-over, or even freshly high mainly wanted to laugh.So I have to admit that today, even 12 years after graduation. I’m still insecure about my own worthless.I have to remind myself today you’re here for areason.Today I feel much like I did when I came to Harvaed Yard as a freshmanin 1999.When you guys were,to my continued shocked and horror, still inkindergarten.I felt like there had been some mistake, that I wasn’t smartenough to be in this company, and that everytime I opened my mouth.I would haveto prove that I was’t just dumb actress.So I start with an apology. This won’tbe very funny. I’m not a comedian6.And I didn’t get a ghost writer.But I am hereto tell you today.Harvard is giving you all diplomas tomorrow. You are here fora reason. Sometimes your insecurities and your inexperience may lead you, too,to embrace other people’s expectations, standards, or values. But you canharness that inexperience to carve out your own path, one that is free of the burden of knowing how things are supposed to be, a path that is defined by itsown particular set of reasons.
 
　　That other day I went to an amusement park with my soon-to-be 4-yeas-old son. And I watch himplay arcade7 games. He was incredible focused, throwing his ball at the target.Jewish mother than I am, I skipped 20 steps and was already imagining him as amajor league player with what is his arm and his arm and his concentration. Butthen I realized what he want. He was playing to trade in his tickets for thecrappy plastic toy. The prize was much more excting than the game to get it. Iof course wanted to urge him to take joy and the challenge of the game, theimprovement upon practice, the satisfaction of doing something well, and evenfeeling the accomplishment8 when achieving the game’s goals. But all of theseaspects were shaded by the 10 cent plastic men with sticky stretchy blue armsthat adhere to the walls. That-that was the prize. In a child’s nature, we seemany of our own innate9 tendencies. I saw myself in him and perhaps you do too.Prizes serve as false idols10 everywhere(圣经里的false idol). Prestige, wealth, fame, power. You’ll be exposedto many of these, if not all. Of course, part of why I was invited to come to speak today beyond my being a proud alumma is that I’ve recruited some verycoveted toys in my life including a not so plastic, not so crappy one: anOscar. So we bump up against the common troll I think of the commencement address people who have achieved a lot telling you that the fruits of the achievement are not always to be trusted. But I think that contradiction can be reconciled and is in fact instructive. Achievement is wonderful when you knowwhy you’re doing it. And when you don’t know, it can be a terrible trap.
 
　　I went to apublic high school on Long Island, Syosset High School. Ooh, hello, Syosset!The girls I went to school with had Prada bags and flat-ironed hair. And theyspoke with an accent I who had moved there at age 9 from Connecticut mimickedto fit in. Florida Oranges, Chocolate cherries. Since I ’m ancient and the Internet was just starting when I was in high school. People didn’t really pay that much of attention to the fact that that I was an actress. I was known mainly at school for having a back bigger than I was and always havingwhite-out on my hands because I hated seeing anything crossed out in my notebooks. I was voted for my senior yearbook ‘ most likely to be an contestant11 onJeopardy ’ or code for nerdiest. When I got to Harvard just after the releaseof Star Wars: Episode 1, I knew I would be staring over in terms of how people viewed me. I feared people would have assumed I’d gotten in just for beingfamous, and that they would think that I was not worthy12 of the intellectualrigor here. And it would not have been far from the truth.
 
　　When I came here I had never written a 10-pape paper before. I’m not even sure I’ve writtena 5-page paper. I was alarmed and intimidated13 by the calm eyes of a fellowstudent who came here from Dalton or Exeter who thought that compared to highschool the workload14 here was easy. I was completely overwhelmed and thought thatreading 1000 pages a week was unimaginable, that writing a 50-page thesis isjust something I could never do. I Had no idea how to declare my intentions. Icould’t even articulate them to myself. I’ve been acting15 since I was 11. But Ithought acting was too frivolous16 and certainly not meaningful. I came from afamily of academics and was very concerned of being taken seriously.
 
　　Incontrast to my inability to declare myself, on my first day of orientation17 freshman5 year, five separate students introduced themselves to me by saying,I’m going to be president. Remember I told you that. Their names, for therecord, were Bernie Sanders, Marco Rubio, Ted4 Cruz, Barack Obama, HilaryClinton. In all seriousness, I believed every one of them. Their bearing andself-confidence alone seemed proof of their prophecy where I couldn’t shake myself-doubt. I got in only because I was famous. This was how others saw me andit was how I saw myself. Driven by these insecurities, I decided18 I was going tofind something to do in Harvard that was serious and meaningful that wouldchange the world and make it a better place.
 
　　At the age of18, I’d already been acting for 7 years, and assumed I find a more serious andprofound path in college. So freshman fall I decided to take neurobiology andadvanced modern Hebrew literature because I was serious and intellectual.Needless to say, I should have failed both. I got Bs, for your information, andto this day, every Sunday I burn a small effigy19 to the pagan Gods of gradeinflation. But as I was fighting my way through Aleph Bet Yod Y shua in Hebrewand the different mechanisms20 of neuro-response, I saw friends around me writingpapers on sailing and pop culture magazines, and professors teaching classes onfairy tales and The Matrix. I realized that seriousness for seriousness’s sakewas its own kind of trophy21, and a dubious22 one, a pose I sought to counter somehalf-imagined argument about who I was. There was a reason that I was an actor.I love what I do. And I saw from my peers and my mentors23 that it was not onlyan acceptable reason, it was the best reason.
 
　　When I got tomy graduation, siting where you sit today, after 4 years of trying to getexcited about something else, I admitted to myself that I couldn’t wait to goback and make more films. I wanted to tell stories, to imagine the lives ofothers and help others do the same. I have found or perhaps reclaimed24 myreason. You have a prize now or at least you will tomorrow. The prize isHarvard degree in your hand. But what is your reason behind it ? My Harvarddegree represents, for me, the curiosity and invention that were encouragedhere, the friendships I’ve sustained the way Professor Graham told me not todescribe the way light hit a flower but rather the shadow the flower cast, theway Professor Scarry talked about theatre is a teansformative religious forcehow professor Coslin showed how much our visual cortex is activated25 just byimaging.Now granted these things don’t necessarily help me answer the mostcommon question I’m asked: What designer are you wearing? What’s your fitnessregime? Any makeup26 tips? But I have never since been embarrassed to myself aswhat I might previously27 have thought was a stupid question. My Harvard degreeand other awards are emblems28 of the experiences which led me to them. The woodpaneled lecture halls, the colorful fall leaves, the hot vanilla29 Toscaninis,reading great novels in overstuffed library chairs, running through dininghalls sceaming: Ooh! Ah! City steps! City steps! City steps! City steps!
 
　　It’s easy now toromanticize my time here. But I had some very difficult times here too. Some combination of being 19, dealing30 with my first heartbreak, taking birth controlpills that since been taken off the market for their depressive side effects,and spending too much time missing daylight during winter mouths led me to somepretty dark moments, particularly during sophomore31 year. There were several occasions where I started crying in meeting with professors overwhelmed withwhat I was supposed to pull off when I could barely get myself out of bed in the morning. Moments when I took on the motto for school work. Done. Not good.If only I could finish my work, even if it took eating a jumbo pack of sourPatch Kids to get me through a single 10-page paper. I felt that I’veaccomplished a great feat32. I repeat to myself. Done. Not good.
 
　　A couple of years ago, I went to Tokyo with my husband and I ate at the most remarkable33 sushi restaurant. I don’t even eat fish. I’m vegan. So that tells you how goodit was. Even with just vegetables, this sushi was the stuff you dreamed about.The restaurant has six seats. My husband and I marveled at how anyone can makerice so superior to all other rice. We wondered why they didn’t make a biggerrestaurant and be the most popular place in town. Our local friend explain tous that all the best restaurants in Tokyo are that small and do only one typeof dish: sushi or tempura or teriyaki. Because they want to do that thing welland beautifully. And it’s not about quantity. It’s about taking pleasure in theperfection and beauty of the particular. I’m still learning now that it’s aboutgood and maybe never done. And the joy and work ethic34 and virtuosity35 we bringto the particular can impart a singular type of enjoyment36 to those we give toand of course, ourselves.
 
　　In my professionallife, it also took me time to find my own reasons for doing my work. The firstfilm I was in came out in 1994. Again, appallingly37, the year most of you wereborn. I was 13 years old upon the film’s release and I can still quote what theNew York Times said about me verbatim. Ms Portman poses better than she acts.The film had universally tepid38 critic response and went on to bombcommercially. That film was called The Professional, or Leon in Europe. Andtoday, 20 years and 35 films later, it is still the film people approach meabout the most to tell me how much they loved it, how much they moved them, howit’s their favorite movie. I feel lucky that my first experience of releasing afilm was initially39 such a disaster by all standards and measures.
 
　　I learned early that my meaning had to be from the experience of making film and thepossibility of connecting with individuals rather than the foremost trophies40 inmy industry: financial and critical success. And also these initial reactionscould be false predictors of your work’s ultimate legacy41, I started choosingonly jobs that I’m passionate42 about and from which I knew I could gleanmeaningful experiences. This thoroughly43 confused everyone around me: agents,producers, and audiences alike. I made Gotya’s Ghost, a foreign independentfilm and study our history visiting the produce everyday for 4 months as I readabout Goya and the Spanish Inquisition. I made for Vendetta44, studio actionmovie for which I learned everything I could about freedom fighters whomotherwise may be called terrorists, from Menachem Begin to Weather Underground.I made Your Highness, a pothead comedy with Danny McBride and laughed for 3months straight. I was able to own my meaning ant not have it be determined45 bybox office receipts or prestige. By the time I got to making Black Swan, theexperience was entirely46 my own. I felt immune to the worst things anyone couldsay or write about me, and to whether the audience felt like to see my movie ornot. It was instructive for me to see for ballet dancers once your techniquegets to a certain level, the only thing that separates you from others is yourquirks or even flaws. One ballerina was famous for how she turned slightly offbalanced. You can never be the best, technically47. Some will always have ahigher jump or a more beautiful line. The only thing you can be the best at isdeveloping your own self. Authoring your own experience was very much whatBlack Swan itself was about. I worked with Darren Aronofsky the director whochanged my last line in the movie to it was perfect. My character Nina is onlyartistically successful when she finds perfection and pleasure for herself notwhen she was trying to be perfect in the eyes of others. So when Black Swan wassuccessful financially and I began receiving accolades49 I felt honored andgrateful to have connected with people. But the true core of my meaning I hadalready established. And I needed it to be independent of people’s reactions tome. People told me that Black Swan was an artistic48 risk, a scary challenge totry to portray50 a professional ballet dancer. But it didn’t feel like courage ordaring that drove me do it. I was so oblivious51 to my own limits that I didthings I was woefully unprepared to do. And so the very inexperience that incollege had made me insecure and made me want to play by other’s rules now ismaking me actually take risks I didn’t even realize were risks. When Darrenasked me if I could do ballet I told him I was basically a ballerina which bythe way I wholeheartedly believed. When it quickly became clear that preparingfor film that I was 15 years away from being a ballerina. It made me work amillion times harder and of course the magic of cinema and body doubles helpedthe final effect.
 
　　But the point is, if I had known my own limitations I neverwould take of the risk. And the risk led to one of my greatest artisticpersonal experiences. And that I not only felt completely free. I also met myhusband during the filming. Similarly, I just directed my first film, A Tale oflove in Darkness. I was quite blind to the challenges ahead of me. The film is a period film, completely in Hebrew in which I also act with an eight-year-oldchild as a costar. All of these are challenges I should have been terrified of,as I was completely unprepared for them but my complete ignorance to my ownlimitations looked like confidence and got me into the director’s chair. Once here, I have to figure it all out, and my belief that I could handle thesethings contrary to all evidence of my ability or do so was only half thebattle. The other half was very hard work. The experience was the deepest andmost meaningful one of my career. Now clearly I’m not urging you to go andperform heart surgery without the knowledge to do so! Making movies admittedlyhas less drastic consequences than most professions and allows for a lot ofeffects that make up for mistakes. The thing I’m saying is, make use of thefact that you don’t doubt yourself too much right now. As we get older, we getmore realistic, and that includes about our own abilities or lack thereof. Andthat realism does us no favors. People always talk about diving into thingsyou’re afraid of. That never worked for me. If I am afraid, I run away. And Iwould probably urge my child to do the same. Fear protects us in many ways.What has served me is diving into my own obliviousness52. Being more confidentthan I should be which everyone tends to decry53 American kids, and those of us who have been grade inflated54 and ego55 inflated. Well. It can be a good thing ifit makes you try things you never might have tried. Your inexperience is anasset, and will allow you to think in original and unconventional way. Acceptyour lack of knowledge and use it as your asset. I know a famous violinist who told me that he can’t compose because he knows too many pieces so when he starts thinking of the note an existing piece immediately comes to mind. Juststarting out of your digest strengths is not known how things are supposed tobe. You can compose freely because your mind isn’t cluttered56 with too manypieces. And you don’t take for granted the way how things are. The only way youknow how to do things is your own way. You here will all go on to achieve greatthings. There is no doubt about that. Each time you set out to do something newyour inexperience can either lead you down a path where you will conform tosomeone else’s values or you can forge your own path. Even though you don’trealize that’s what you’re doing. If your reasons are your own, your path, evenif it’s a strange and clumsy path, will be wholly yours, and you will controlthe rewards of what you do by making your internal life fulfilling.
 
　　At the risk of sounding like a Miss American Contestant, the most fulfilling things I’ve experienced have truly been the human interactions: spending time with women invillage banks in Mexico with FINCA microfinance organization, meeting youngwomen who were the first and the only in their communities to attend secondaryschools in rural Kenya with free the Children group that built sustainableschools in developing countries tracking with gorilla57 conservationists inRwanda. It’s cliché, because it’s true, that helping58 other ends up helping youmore than anyone. Getting out of your own concerns and caring about some else’slife for a while, remind you that you are not the central of the universe. Andthat in the ways we’re generous or not, We can change course of someone’s life.…have had the most lasting59 impact. And of course, first and foremost, thecenter of my world is the love that I share with my family and friends. I wishfor you that your friends will be with you through it all as my friends fromHarvard have been together since we graduated. Grab the good people around youand don’t let them go. To be or not to be is not the question; the vitalquestion is how to be and how not to be. Thank you! I can’t wait to see you doall the beautiful thins you will do.
活动入口：金融养猪猪
一键开完所有的宝箱功能。耗时70秒
大转盘抽奖
喂食
每日签到
完成分享任务得猪粮

===============Quantumultx===============
[task_local]
#京东金融养猪猪
12 * * * * https://gitee.com/lxk0301/jd_scripts/raw/master/jd_pigPet.js, tag=京东金融养猪猪, img-url=https://raw.githubusercontent.com/58xinian/icon/master/jdyz.png, enabled=true

================Loon==============
[Script]
cron "12 * * * *" script-path=https://gitee.com/lxk0301/jd_scripts/raw/master/jd_pigPet.js, tag=京东金融养猪猪

===============Surge=================
京东金融养猪猪 = type=cron,cronexp="12 * * * *",wake-system=1,timeout=3600,script-path=https://gitee.com/lxk0301/jd_scripts/raw/master/jd_pigPet.js

============小火箭=========
京东金融养猪猪 = type=cron,script-path=https://gitee.com/lxk0301/jd_scripts/raw/master/jd_pigPet.js, cronexpr="12 * * * *", timeout=3600, enable=true
 */

const $ = new Env('金融养猪');
let cookiesArr = [], cookie = '';
const JD_API_HOST = 'https://ms.jr.jd.com/gw/generic/uc/h5/m';
const MISSION_BASE_API = `https://ms.jr.jd.com/gw/generic/mission/h5/m`;
const notify = $.isNode() ? require('./sendNotify') : '';
//Node.js用户请在jdCookie.js处填写京东ck;
const jdCookieNode = $.isNode() ? require('./jdCookie.js') : '';
if ($.isNode()) {
  Object.keys(jdCookieNode).forEach((item) => {
    cookiesArr.push(jdCookieNode[item])
  })
  if (process.env.JD_DEBUG && process.env.JD_DEBUG === 'false') console.log = () => {};
} else {
  let cookiesData = $.getdata('CookiesJD') || "[]";
  cookiesData = jsonParse(cookiesData);
  cookiesArr = cookiesData.map(item => item.cookie);
  cookiesArr.reverse();
  cookiesArr.push(...[$.getdata('CookieJD2'), $.getdata('CookieJD')]);
  cookiesArr.reverse();
  cookiesArr = cookiesArr.filter(item => item !== "" && item !== null && item !== undefined);
}
!(async () => {
  if (!cookiesArr[0]) {
    $.msg($.name, '【提示】请先获取京东账号一cookie\n直接使用NobyDa的京东签到获取', 'https://bean.m.jd.com/bean/signIndex.action', {"open-url": "https://bean.m.jd.com/bean/signIndex.action"});
    return;
  }
  for (let i = 0; i < cookiesArr.length; i++) {
    if (cookiesArr[i]) {
      cookie = cookiesArr[i];
      $.UserName = decodeURIComponent(cookie.match(/pt_pin=(.+?);/) && cookie.match(/pt_pin=(.+?);/)[1])
      $.index = i + 1;
      $.isLogin = true;
      $.nickName = '';
      await TotalBean();
      console.log(`\n开始【京东账号${$.index}】${$.nickName || $.UserName}\n`);
      if (!$.isLogin) {
        $.msg($.name, `【提示】cookie已失效`, `京东账号${$.index} ${$.nickName || $.UserName}\n请重新登录获取\nhttps://bean.m.jd.com/bean/signIndex.action`, {"open-url": "https://bean.m.jd.com/bean/signIndex.action"});
        if ($.isNode()) {
          await notify.sendNotify(`${$.name}cookie已失效 - ${$.UserName}`, `京东账号${$.index} ${$.UserName}\n请重新登录获取cookie`);
        }
        continue
      }
      await jdPigPet();
    }
  }
})()
    .catch((e) => {
      $.log('', `❌ ${$.name}, 失败! 原因: ${e}!`, '')
    })
    .finally(() => {
      $.done();
    })
async function jdPigPet() {
  await pigPetLogin();
  if (!$.hasPig) return
  await pigPetSignIndex();
  await pigPetSign();
  await pigPetOpenBox();
  await pigPetLotteryIndex();
  await pigPetLottery();
  await pigPetMissionList();
  await missions();
  await pigPetUserBag();
}
async function pigPetLottery() {
  if ($.currentCount > 0) {
    for (let i = 0; i < $.currentCount; i ++) {
      await pigPetLotteryPlay();
    }
  }
}
async function pigPetSign() {
  if (!$.sign) {
    await pigPetSignOne();
  } else {
    console.log(`第${$.no}天已签到\n`)
  }
}
function pigPetSignOne() {
  return new Promise(async resolve => {
    const body = {
      "source":2,
      "channelLV":"juheye",
      "riskDeviceParam": "{}",
      "no": $.no
    }
    $.post(taskUrl('pigPetSignOne', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            console.log('签到结果',data)
            // data = JSON.parse(data);
            // if (data.resultCode === 0) {
            //   if (data.resultData.resultCode === 0) {
            //     if (data.resultData.resultData) {
            //       console.log(`当前大转盘剩余免费抽奖次数：：${data.resultData.resultData.currentCount}`);
            //       $.sign = data.resultData.resultData.sign;
            //       $.no = data.resultData.resultData.today;
            //     }
            //   } else {
            //     console.log(`查询签到情况异常：${JSON.stringify(data)}`)
            //   }
            // }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//查询背包食物
function pigPetUserBag() {
  return new Promise(async resolve => {
    const body = {"source":0,"channelLV":"yqs","riskDeviceParam":"{}","t":Date.now(),"skuId":"1001003004","category":"1001"};
    $.post(taskUrl('pigPetUserBag', body), async (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData && data.resultData.resultData.goods) {
                  console.log(`\n食物名称     数量`);
                  for (let item of data.resultData.resultData.goods) {
                    console.log(`${item.goodsName}      ${item.count}g`);
                  }
                  for (let item of data.resultData.resultData.goods) {
                    if (item.count >= 20) {
                      console.log(`10秒后开始喂食${item.goodsName}，当前数量为${item.count}g`)
                      await $.wait(10000);
                      await pigPetAddFood(item.sku);
                    }
                  }
                } else {
                  console.log(`暂无食物`)
                }
              } else {
                console.log(`开宝箱其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//喂食
function pigPetAddFood(skuId) {
  return new Promise(async resolve => {
    console.log(`skuId::::${skuId}`)
    const body = {
      "source": 0,
      "channelLV":"yqs",
      "riskDeviceParam":"{}",
      "skuId": skuId.toString(),
      "category":"1001",
    }
    // const body = {
    //   "source": 2,
    //   "channelLV":"juheye",
    //   "riskDeviceParam":"{}",
    //   "skuId": skuId.toString(),
    // }
    $.post(taskUrl('pigPetAddFood', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            console.log(`喂食结果：${data}`)
            data = JSON.parse(data);
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
function pigPetLogin() {
  return new Promise(async resolve => {
    const body = {
      "source":2,
      "channelLV":"juheye",
      "riskDeviceParam":"{}",
    }
    $.post(taskUrl('pigPetLogin', body), async (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                $.hasPig = data.resultData.resultData.hasPig;
                if (!$.hasPig) {
                  console.log(`\n京东账号${$.index} ${$.nickName} 未开启养猪活动,请手动去京东金融APP开启此活动\n`)
                }
              } else {
                console.log(`Login其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//开宝箱
function pigPetOpenBox() {
  return new Promise(async resolve => {
    const body = {"source":0,"channelLV":"yqs","riskDeviceParam":"{}","no":5,"category":"1001","t": Date.now()}
    $.post(taskUrl('pigPetOpenBox', body), async (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            // console.log(data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData && data.resultData.resultData.award) {
                  console.log(`开宝箱获得${data.resultData.resultData.award.content}，数量：${data.resultData.resultData.award.count}`);

                } else {
                  console.log(`开宝箱暂无奖励`)
                }
                await $.wait(2000);
                await pigPetOpenBox();
              } else if (data.resultData.resultCode === 420) {
                console.log(`开宝箱失败:${data.resultData.resultMsg}`)
              } else {
                console.log(`开宝箱其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//查询大转盘的次数
function pigPetLotteryIndex() {
  $.currentCount = 0;
  return new Promise(async resolve => {
    const body = {
      "source":0,
      "channelLV":"juheye",
      "riskDeviceParam": "{}"
    }
    $.post(taskUrl('pigPetLotteryIndex', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            // console.log(data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData) {
                  console.log(`当前大转盘剩余免费抽奖次数：：${data.resultData.resultData.currentCount}`);
                  $.currentCount = data.resultData.resultData.currentCount;
                }
              } else {
                console.log(`查询大转盘的次数：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//查询签到情况
function pigPetSignIndex() {
  $.sign = true;
  return new Promise(async resolve => {
    const body = {
      "source":2,
      "channelLV":"juheye",
      "riskDeviceParam": "{}"
    }
    $.post(taskUrl('pigPetSignIndex', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            // console.log(data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData) {
                  $.sign = data.resultData.resultData.sign;
                  $.no = data.resultData.resultData.today;
                }
              } else {
                console.log(`查询签到情况异常：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//抽奖
function pigPetLotteryPlay() {
  return new Promise(async resolve => {
    const body = {
      "source":0,
      "channelLV":"juheye",
      "riskDeviceParam":"{}",
      "t":Date.now(),
      "type":0,
    }
    $.post(taskUrl('pigPetLotteryPlay', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            // console.log(data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData) {
                  // console.log(`当前大转盘剩余免费抽奖次数：：${data.resultData.resultData.currentCount}`);
                  $.currentCount = data.resultData.resultData.currentCount;//抽奖后剩余的抽奖次数
                }
              } else {
                console.log(`其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
async function missions() {
  for (let item of $.missions) {
    if (item.status === 4) {
      console.log(`\n${item.missionName}任务已做完,开始领取奖励`)
      await pigPetDoMission(item.mid);
    } else if (item.status === 5){
      console.log(`\n${item.missionName}已领取`)
    } else if (item.status === 3){
      console.log(`\n${item.missionName}未完成`)
      if (item.mid === 'CPD01') {
        await pigPetDoMission(item.mid);
      } else {
        //TODO
        // await pigPetDoMission(item.mid);
        // await queryMissionReceiveAfterStatus(item.mid);
        // await finishReadMission(item.mid);
      }
    }
  }
}
//领取做完任务的奖品
function pigPetDoMission(mid) {
  return new Promise(async resolve => {
    const body = {
      "source":0,
      "channelLV":"",
      "riskDeviceParam":"{}",
      mid
    }
    $.post(taskUrl('pigPetDoMission', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            console.log('pigPetDoMission',data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData) {
                  if (data.resultData.resultData.award) {
                    console.log(`奖励${data.resultData.resultData.award.name},数量:${data.resultData.resultData.award.count}`)
                  }
                }
              } else {
                console.log(`其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//查询任务列表
function pigPetMissionList() {
  return new Promise(async resolve => {
    const body = {
      "source":0,
      "channelLV":"",
      "riskDeviceParam":"{}",
    }
    $.post(taskUrl('pigPetMissionList', body), (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            // console.log(data)
            data = JSON.parse(data);
            if (data.resultCode === 0) {
              if (data.resultData.resultCode === 0) {
                if (data.resultData.resultData) {
                  $.missions = data.resultData.resultData.missions;//抽奖后剩余的抽奖次数
                }
              } else {
                console.log(`其他情况：${JSON.stringify(data)}`)
              }
            }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
function queryMissionReceiveAfterStatus(missionId) {
  return new Promise(resolve => {
    const body = {"missionId": missionId.toString()};
    const options = {
      "url": `${MISSION_BASE_API}/queryMissionReceiveAfterStatus?reqData=%7B%2522missionId%2522:%2522${Number(missionId)}%2522%7D`,
      "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Host": "ms.jr.jd.com",
        "Cookie": cookie,
        "Origin": "https://jdjoy.jd.com",
        "Referer": "https://jdjoy.jd.com/",
        "User-Agent": $.isNode() ? (process.env.JD_USER_AGENT ? process.env.JD_USER_AGENT : (require('./USER_AGENTS').USER_AGENT)) : ($.getdata('JDUA') ? $.getdata('JDUA') : "jdapp;iPhone;9.2.2;14.2;%E4%BA%AC%E4%B8%9C/9.2.2 CFNetwork/1206 Darwin/20.1.0")
      }
    }
    $.get(options, (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            console.log('queryMissionReceiveAfterStatus',data)
            // data = JSON.parse(data);
            // if (data.resultCode === 0) {
            //   if (data.resultData.resultCode === 0) {
            //     if (data.resultData.resultData) {
            //       // console.log(`当前大转盘剩余免费抽奖次数：：${data.resultData.resultData.currentCount}`);
            //       $.currentCount = data.resultData.resultData.currentCount;//抽奖后剩余的抽奖次数
            //     }
            //   } else {
            //     console.log(`其他情况：${JSON.stringify(data)}`)
            //   }
            // }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
//做完浏览任务发送信息API
function finishReadMission(missionId) {
  return new Promise(async resolve => {
    const body = {"missionId": missionId.toString(),"readTime":10};
    const options = {
      "url": `${MISSION_BASE_API}/finishReadMission?reqData=%7B%2522missionId%2522:%2522${Number(missionId)}%2522,%2522readTime%2522:10%7D`,
      "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Connection": "keep-alive",
        "Host": "ms.jr.jd.com",
        "Cookie": cookie,
        "Origin": "https://jdjoy.jd.com",
        "Referer": "https://jdjoy.jd.com/",
        "User-Agent": $.isNode() ? (process.env.JD_USER_AGENT ? process.env.JD_USER_AGENT : (require('./USER_AGENTS').USER_AGENT)) : ($.getdata('JDUA') ? $.getdata('JDUA') : "jdapp;iPhone;9.2.2;14.2;%E4%BA%AC%E4%B8%9C/9.2.2 CFNetwork/1206 Darwin/20.1.0")
      }
    }
    $.get(options, (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            console.log('finishReadMission',data)
            // data = JSON.parse(data);
            // if (data.resultCode === 0) {
            //   if (data.resultData.resultCode === 0) {
            //     if (data.resultData.resultData) {
            //       // console.log(`当前大转盘剩余免费抽奖次数：：${data.resultData.resultData.currentCount}`);
            //       $.currentCount = data.resultData.resultData.currentCount;//抽奖后剩余的抽奖次数
            //     }
            //   } else {
            //     console.log(`其他情况：${JSON.stringify(data)}`)
            //   }
            // }
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
function TotalBean() {
  return new Promise(async resolve => {
    const options = {
      "url": `https://wq.jd.com/user/info/QueryJDUserInfo?sceneval=2`,
      "headers": {
        "Accept": "application/json,text/plain, */*",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "zh-cn",
        "Connection": "keep-alive",
        "Cookie": cookie,
        "Referer": "https://wqs.jd.com/my/jingdou/my.shtml?sceneval=2",
        "User-Agent": $.isNode() ? (process.env.JD_USER_AGENT ? process.env.JD_USER_AGENT : (require('./USER_AGENTS').USER_AGENT)) : ($.getdata('JDUA') ? $.getdata('JDUA') : "jdapp;iPhone;9.2.2;14.2;%E4%BA%AC%E4%B8%9C/9.2.2 CFNetwork/1206 Darwin/20.1.0")
      }
    }
    $.post(options, (err, resp, data) => {
      try {
        if (err) {
          console.log(`${JSON.stringify(err)}`)
          console.log(`${$.name} API请求失败，请检查网路重试`)
        } else {
          if (data) {
            data = JSON.parse(data);
            if (data['retcode'] === 13) {
              $.isLogin = false; //cookie过期
              return
            }
            $.nickName = data['base'].nickname;
          } else {
            console.log(`京东服务器返回空数据`)
          }
        }
      } catch (e) {
        $.logErr(e, resp)
      } finally {
        resolve();
      }
    })
  })
}
function taskUrl(function_id, body) {
  return {
    url: `${JD_API_HOST}/${function_id}?_=${Date.now()}`,
    body: `reqData=${encodeURIComponent(JSON.stringify(body))}`,
    headers: {
      'Accept' : `*/*`,
      'Origin' : `https://u.jr.jd.com`,
      'Accept-Encoding' : `gzip, deflate, br`,
      'Cookie' : cookie,
      'Content-Type' : `application/x-www-form-urlencoded;charset=UTF-8`,
      'Host' : `ms.jr.jd.com`,
      'Connection' : `keep-alive`,
      // 'User-Agent' : `jdapp;iPhone;9.0.0;13.4.1;e35caf0a69be42084e3c97eef56c3af7b0262d01;network/4g;ADID/F75E8AED-CB48-4EAC-A213-E8CE4018F214;supportApplePay/3;hasUPPay/0;pushNoticeIsOpen/1;model/iPhone11,8;addressid/2005183373;hasOCPay/0;appBuild/167237;supportBestPay/0;jdSupportDarkMode/0;pv/1287.19;apprpd/MyJD_GameMain;ref/https%3A%2F%2Fuua.jr.jd.com%2Fuc-fe-wxgrowing%2Fmoneytree%2Findex%2F%3Fchannel%3Dyxhd%26lng%3D113.325843%26lat%3D23.204628%26sid%3D2d98e88cf7d182f60d533476c2ce777w%26un_area%3D19_1601_50258_51885;psq/1;ads/;psn/e35caf0a69be42084e3c97eef56c3af7b0262d01|3485;jdv/0|kong|t_1000170135|tuiguang|notset|1593059927172|1593059927;adk/;app_device/IOS;pap/JA2015_311210|9.0.0|IOS 13.4.1;Mozilla/5.0 (iPhone; CPU iPhone OS 13_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148;supportJDSHWK/1`,
      'User-Agent' : `jdapp;android;8.5.12;9;network/wifi;model/GM1910;addressid/1302541636;aid/ac31e03386ddbec6;oaid/;osVer/28;appBuild/73078;adk/;ads/;pap/JA2015_311210|8.5.12|ANDROID 9;osv/9;pv/117.24;jdv/0|kong|t_1000217905_|jingfen|644e9b005c8542c1ac273da7763971d8|1589905791552|1589905794;ref/com.jingdong.app.mall.WebActivity;partner/oppo;apprpd/Home_Main;Mozilla/5.0 (Linux; Android 9; GM1910 Build/PKQ1.190110.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/044942 Mobile Safari/537.36 Edg/86.0.4240.111`,
      'Referer' : `https://u.jr.jd.com/`,
      'Accept-Language' : `zh-cn`
    }
  }
}
function jsonParse(str) {
  if (typeof str == "string") {
    try {
      return JSON.parse(str);
    } catch (e) {
      console.log(e);
      $.msg($.name, '', '请勿随意在BoxJs输入框修改内容\n建议通过脚本去获取cookie')
      return [];
    }
  }
}
// prettier-ignore
function Env(t,e){"undefined"!=typeof process&&JSON.stringify(process.env).indexOf("GITHUB")>-1&&process.exit(0);class s{constructor(t){this.env=t}send(t,e="GET"){t="string"==typeof t?{url:t}:t;let s=this.get;return"POST"===e&&(s=this.post),new Promise((e,i)=>{s.call(this,t,(t,s,r)=>{t?i(t):e(s)})})}get(t){return this.send.call(this.env,t)}post(t){return this.send.call(this.env,t,"POST")}}return new class{constructor(t,e){this.name=t,this.http=new s(this),this.data=null,this.dataFile="box.dat",this.logs=[],this.isMute=!1,this.isNeedRewrite=!1,this.logSeparator="\n",this.startTime=(new Date).getTime(),Object.assign(this,e),this.log("",`🔔${this.name}, 开始!`)}isNode(){return"undefined"!=typeof module&&!!module.exports}isQuanX(){return"undefined"!=typeof $task}isSurge(){return"undefined"!=typeof $httpClient&&"undefined"==typeof $loon}isLoon(){return"undefined"!=typeof $loon}toObj(t,e=null){try{return JSON.parse(t)}catch{return e}}toStr(t,e=null){try{return JSON.stringify(t)}catch{return e}}getjson(t,e){let s=e;const i=this.getdata(t);if(i)try{s=JSON.parse(this.getdata(t))}catch{}return s}setjson(t,e){try{return this.setdata(JSON.stringify(t),e)}catch{return!1}}getScript(t){return new Promise(e=>{this.get({url:t},(t,s,i)=>e(i))})}runScript(t,e){return new Promise(s=>{let i=this.getdata("@chavy_boxjs_userCfgs.httpapi");i=i?i.replace(/\n/g,"").trim():i;let r=this.getdata("@chavy_boxjs_userCfgs.httpapi_timeout");r=r?1*r:20,r=e&&e.timeout?e.timeout:r;const[o,h]=i.split("@"),n={url:`http://${h}/v1/scripting/evaluate`,body:{script_text:t,mock_type:"cron",timeout:r},headers:{"X-Key":o,Accept:"*/*"}};this.post(n,(t,e,i)=>s(i))}).catch(t=>this.logErr(t))}loaddata(){if(!this.isNode())return{};{this.fs=this.fs?this.fs:require("fs"),this.path=this.path?this.path:require("path");const t=this.path.resolve(this.dataFile),e=this.path.resolve(process.cwd(),this.dataFile),s=this.fs.existsSync(t),i=!s&&this.fs.existsSync(e);if(!s&&!i)return{};{const i=s?t:e;try{return JSON.parse(this.fs.readFileSync(i))}catch(t){return{}}}}}writedata(){if(this.isNode()){this.fs=this.fs?this.fs:require("fs"),this.path=this.path?this.path:require("path");const t=this.path.resolve(this.dataFile),e=this.path.resolve(process.cwd(),this.dataFile),s=this.fs.existsSync(t),i=!s&&this.fs.existsSync(e),r=JSON.stringify(this.data);s?this.fs.writeFileSync(t,r):i?this.fs.writeFileSync(e,r):this.fs.writeFileSync(t,r)}}lodash_get(t,e,s){const i=e.replace(/\[(\d+)\]/g,".$1").split(".");let r=t;for(const t of i)if(r=Object(r)[t],void 0===r)return s;return r}lodash_set(t,e,s){return Object(t)!==t?t:(Array.isArray(e)||(e=e.toString().match(/[^.[\]]+/g)||[]),e.slice(0,-1).reduce((t,s,i)=>Object(t[s])===t[s]?t[s]:t[s]=Math.abs(e[i+1])>>0==+e[i+1]?[]:{},t)[e[e.length-1]]=s,t)}getdata(t){let e=this.getval(t);if(/^@/.test(t)){const[,s,i]=/^@(.*?)\.(.*?)$/.exec(t),r=s?this.getval(s):"";if(r)try{const t=JSON.parse(r);e=t?this.lodash_get(t,i,""):e}catch(t){e=""}}return e}setdata(t,e){let s=!1;if(/^@/.test(e)){const[,i,r]=/^@(.*?)\.(.*?)$/.exec(e),o=this.getval(i),h=i?"null"===o?null:o||"{}":"{}";try{const e=JSON.parse(h);this.lodash_set(e,r,t),s=this.setval(JSON.stringify(e),i)}catch(e){const o={};this.lodash_set(o,r,t),s=this.setval(JSON.stringify(o),i)}}else s=this.setval(t,e);return s}getval(t){return this.isSurge()||this.isLoon()?$persistentStore.read(t):this.isQuanX()?$prefs.valueForKey(t):this.isNode()?(this.data=this.loaddata(),this.data[t]):this.data&&this.data[t]||null}setval(t,e){return this.isSurge()||this.isLoon()?$persistentStore.write(t,e):this.isQuanX()?$prefs.setValueForKey(t,e):this.isNode()?(this.data=this.loaddata(),this.data[e]=t,this.writedata(),!0):this.data&&this.data[e]||null}initGotEnv(t){this.got=this.got?this.got:require("got"),this.cktough=this.cktough?this.cktough:require("tough-cookie"),this.ckjar=this.ckjar?this.ckjar:new this.cktough.CookieJar,t&&(t.headers=t.headers?t.headers:{},void 0===t.headers.Cookie&&void 0===t.cookieJar&&(t.cookieJar=this.ckjar))}get(t,e=(()=>{})){t.headers&&(delete t.headers["Content-Type"],delete t.headers["Content-Length"]),this.isSurge()||this.isLoon()?(this.isSurge()&&this.isNeedRewrite&&(t.headers=t.headers||{},Object.assign(t.headers,{"X-Surge-Skip-Scripting":!1})),$httpClient.get(t,(t,s,i)=>{!t&&s&&(s.body=i,s.statusCode=s.status),e(t,s,i)})):this.isQuanX()?(this.isNeedRewrite&&(t.opts=t.opts||{},Object.assign(t.opts,{hints:!1})),$task.fetch(t).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>e(t))):this.isNode()&&(this.initGotEnv(t),this.got(t).on("redirect",(t,e)=>{try{if(t.headers["set-cookie"]){const s=t.headers["set-cookie"].map(this.cktough.Cookie.parse).toString();s&&this.ckjar.setCookieSync(s,null),e.cookieJar=this.ckjar}}catch(t){this.logErr(t)}}).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>{const{message:s,response:i}=t;e(s,i,i&&i.body)}))}post(t,e=(()=>{})){if(t.body&&t.headers&&!t.headers["Content-Type"]&&(t.headers["Content-Type"]="application/x-www-form-urlencoded"),t.headers&&delete t.headers["Content-Length"],this.isSurge()||this.isLoon())this.isSurge()&&this.isNeedRewrite&&(t.headers=t.headers||{},Object.assign(t.headers,{"X-Surge-Skip-Scripting":!1})),$httpClient.post(t,(t,s,i)=>{!t&&s&&(s.body=i,s.statusCode=s.status),e(t,s,i)});else if(this.isQuanX())t.method="POST",this.isNeedRewrite&&(t.opts=t.opts||{},Object.assign(t.opts,{hints:!1})),$task.fetch(t).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>e(t));else if(this.isNode()){this.initGotEnv(t);const{url:s,...i}=t;this.got.post(s,i).then(t=>{const{statusCode:s,statusCode:i,headers:r,body:o}=t;e(null,{status:s,statusCode:i,headers:r,body:o},o)},t=>{const{message:s,response:i}=t;e(s,i,i&&i.body)})}}time(t,e=null){const s=e?new Date(e):new Date;let i={"M+":s.getMonth()+1,"d+":s.getDate(),"H+":s.getHours(),"m+":s.getMinutes(),"s+":s.getSeconds(),"q+":Math.floor((s.getMonth()+3)/3),S:s.getMilliseconds()};/(y+)/.test(t)&&(t=t.replace(RegExp.$1,(s.getFullYear()+"").substr(4-RegExp.$1.length)));for(let e in i)new RegExp("("+e+")").test(t)&&(t=t.replace(RegExp.$1,1==RegExp.$1.length?i[e]:("00"+i[e]).substr((""+i[e]).length)));return t}msg(e=t,s="",i="",r){const o=t=>{if(!t)return t;if("string"==typeof t)return this.isLoon()?t:this.isQuanX()?{"open-url":t}:this.isSurge()?{url:t}:void 0;if("object"==typeof t){if(this.isLoon()){let e=t.openUrl||t.url||t["open-url"],s=t.mediaUrl||t["media-url"];return{openUrl:e,mediaUrl:s}}if(this.isQuanX()){let e=t["open-url"]||t.url||t.openUrl,s=t["media-url"]||t.mediaUrl;return{"open-url":e,"media-url":s}}if(this.isSurge()){let e=t.url||t.openUrl||t["open-url"];return{url:e}}}};if(this.isMute||(this.isSurge()||this.isLoon()?$notification.post(e,s,i,o(r)):this.isQuanX()&&$notify(e,s,i,o(r))),!this.isMuteLog){let t=["","==============📣系统通知📣=============="];t.push(e),s&&t.push(s),i&&t.push(i),console.log(t.join("\n")),this.logs=this.logs.concat(t)}}log(...t){t.length>0&&(this.logs=[...this.logs,...t]),console.log(t.join(this.logSeparator))}logErr(t,e){const s=!this.isSurge()&&!this.isQuanX()&&!this.isLoon();s?this.log("",`❗️${this.name}, 错误!`,t.stack):this.log("",`❗️${this.name}, 错误!`,t)}wait(t){return new Promise(e=>setTimeout(e,t))}done(t={}){const e=(new Date).getTime(),s=(e-this.startTime)/1e3;this.log("",`🔔${this.name}, 结束! 🕛 ${s} 秒`),this.log(),(this.isSurge()||this.isQuanX()||this.isLoon())&&$done(t)}}(t,e)}
